import React from 'react'
import { NavigationContainer } from '@react-navigation/native'
import { createStackNavigator } from '@react-navigation/stack'

import ForumCategoriesScreen, {
  categoriesScreenOptions,
} from '../screens/ForumCategoriesScreen'
import ForumScreen, { forumScreenOptions } from '../screens/ForumScreen'
import SignUpScreen from '../screens/SignUpScreen'
import NewTopic, { newTopicScreenOptions } from '../screens/NewTopic'
import TopicDetailScreen, {
  detailScreenOptions,
} from '../screens/TopicDetailScreen'
import LoginScreen from '../screens/LoginScreen'

const ForumStackNavigator = createStackNavigator()

const ForumNavigator = () => {
  return (
    <NavigationContainer>
      <ForumStackNavigator.Navigator>
        <ForumStackNavigator.Screen
          name='SignUp'
          component={SignUpScreen}
          options={{ headerShown: false }}
        />
        <ForumStackNavigator.Screen
          name='Login'
          component={LoginScreen}
          options={{ headerShown: false }}
        />
        <ForumStackNavigator.Screen
          name='Forum'
          component={ForumScreen}
          options={forumScreenOptions}
        />
        <ForumStackNavigator.Screen
          name='Detail'
          component={TopicDetailScreen}
          options={detailScreenOptions}
        />
        <ForumStackNavigator.Screen
          name='ForumCategories'
          component={ForumCategoriesScreen}
          options={categoriesScreenOptions}
        />
        <ForumStackNavigator.Screen
          name='NewTopic'
          component={NewTopic}
          options={newTopicScreenOptions}
        />
      </ForumStackNavigator.Navigator>
    </NavigationContainer>
  )
}

export default ForumNavigator
