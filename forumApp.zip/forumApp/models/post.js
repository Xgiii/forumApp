class Post {
  constructor(id, categoryId, title, avatar, username, description) {
    this.id = id
    this.categoryId = categoryId
    this.title = title
    this.avatar = avatar
    this.username = username
    this.description = description
  }
}

export default Post
