import { CardStyleInterpolators } from '@react-navigation/stack'
import React from 'react'
import { View, Text, ScrollView, Image, TouchableOpacity } from 'react-native'
import { TextInput } from 'react-native-gesture-handler'
import Card from '../components/Card'

import Colors from '../constants/Colors'

const TopicDetailScreen = (props) => {
  const data = props.route.params ? props.route.params : {}

  const descriptionLength = data.description.length

  let height

  if (descriptionLength < 100) {
    height = 170
  }
  if (descriptionLength > 100) {
    height = 190
  }
  if (descriptionLength > 200) {
    height = 240
  }
  if (descriptionLength > 400) {
    height = 320
  }
  if (descriptionLength > 550) {
    height = 370
  }

  const replyHandler = () => {
    return (
      <View>
        <TextInput style={{ borderBottomWidth: 1 }} />
      </View>
    )
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#FFFFFF' }}>
      <Card style={{ width: '95%', height: height }} isView={View}>
        <View
          style={{
            margin: 15,
            flexDirection: 'row',
          }}
        >
          <View style={{ marginRight: 15 }}>
            <Image
              source={{ uri: data.avatar }}
              style={{ width: 55, height: 55, borderRadius: 50 }}
            />
          </View>
          <View style={{ flex: 1, marginTop: 8 }}>
            <Text style={{ fontSize: 22, fontFamily: 'Roboto-Bold' }}>
              {data.username}
            </Text>
          </View>
          <View
            style={{
              flexDirection: 'row',
              marginTop: '3%',
            }}
          >
            <TouchableOpacity style={{ marginRight: 10 }}>
              <Image
                source={require('../assets/icons/edit.png')}
                style={{
                  width: 25,
                  height: 25,
                  tintColor: Colors.brandSuccess,
                }}
              />
            </TouchableOpacity>
            <TouchableOpacity>
              <Image
                source={require('../assets/icons/delete.png')}
                style={{ width: 25, height: 25, tintColor: Colors.brandDanger }}
              />
            </TouchableOpacity>
          </View>
        </View>
        <View
          style={{
            flex: 1,
            marginHorizontal: 15,
            justifyContent: 'flex-start',
          }}
        >
          <Text
            style={{ textAlign: 'justify', color: 'rgba(150,150,150,150)' }}
          >
            {data.description}
          </Text>
        </View>
        <View style={{ flexDirection: 'row' }}>
          <TouchableOpacity
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              marginHorizontal: 10,
            }}
            onPress={replyHandler}
          >
            <View style={{ marginHorizontal: 7, marginVertical: 10 }}>
              <Text
                style={{
                  fontSize: 16,
                  color: Colors.brandPrimary,
                  fontFamily: 'Roboto-Bold',
                }}
              >
                Reply
              </Text>
            </View>
            <Image
              source={require('../assets/icons/reply.png')}
              style={{ width: 15, height: 15 }}
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={{ position: 'absolute', bottom: 10, right: '10%' }}
          >
            <Image
              source={require('../assets/icons/like.png')}
              style={{ width: 20, height: 20 }}
            />
          </TouchableOpacity>
        </View>
      </Card>
    </ScrollView>
  )
}

export const detailScreenOptions = (navData) => {
  const routeParams = navData.route.params ? navData.route.params : {}

  return {
    headerTitle: routeParams.title,
    headerTitleAlign: 'center',
    headerStyle: {
      backgroundColor: Colors.brandPrimary,
    },
    headerTintColor: 'white',
    headerTitleStyle: {
      fontSize: 25,
    },
  }
}

export default TopicDetailScreen
