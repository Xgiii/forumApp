import React from 'react'
import {
  View,
  Text,
  TextInput,
  Image,
  ScrollView,
  TouchableOpacity,
} from 'react-native'
import { color } from 'react-native-reanimated'
import LoginField from '../components/LoginField'

import Colors from '../constants/Colors'

const NewTopicScreen = (props) => {
  const data = props.route.params

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#FFFFFF' }}>
      <View style={{ flex: 1, alignItems: 'center', marginTop: '25%' }}>
        <Text style={{ fontSize: 20, fontFamily: 'Roboto-Bold' }}>
          Add a new topic to {data.categoryTitle}
        </Text>
        <View style={{ marginTop: 40 }}>
          <LoginField
            placeholder='Title'
            icon={require('../assets/icons/font.png')}
            isMultiline={false}
            style={{
              width: 20,
              height: 20,
              tintColor: 'rgba(150,150,150,150)',
            }}
            width={'80%'}
            height={45}
          />
        </View>
        <View
          style={{
            width: '75%',
            height: 300,
            marginBottom: 25,
            borderColor: 'rgb(229,229,229)',
            borderWidth: 1,
            borderStyle: 'solid',
            borderRadius: 50,
            backgroundColor: '#FFFFFF',
          }}
        >
          <TextInput
            multiline
            placeholder='Description'
            style={{
              marginHorizontal: 30,
              marginVertical: 10,
              borderBottomWidth: 1,
              borderBottomColor: 'rgba(150,150,150,150)',
            }}
          />
        </View>
      </View>
    </ScrollView>
  )
}

export const newTopicScreenOptions = (navData) => {
  return {
    title: 'New Topic',
    headerTitleAlign: 'center',
    headerStyle: {
      backgroundColor: Colors.brandPrimary,
    },
    headerTintColor: 'white',
    headerTitleStyle: {
      fontSize: 30,
    },
    headerRight: () => {
      return (
        <TouchableOpacity style={{ marginHorizontal: 15 }}>
          <Image
            source={require('../assets/icons/confirm.png')}
            style={{ width: 25, height: 25, tintColor: 'white' }}
          />
        </TouchableOpacity>
      )
    },
  }
}

export default NewTopicScreen
