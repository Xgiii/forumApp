import React from 'react'
import { View, Text, FlatList, TouchableOpacity, Image } from 'react-native'
import Colors from '../constants/Colors'
import { POSTS } from '../data/dummy-data'
import Card from '../components/Card'

const ForumScreen = (props) => {
  const catId = props.route.params.categoryId

  const displayedPosts = POSTS.filter(
    (post) => post.categoryId.indexOf(catId) >= 0
  )

  const post = (itemData) => {
    return (
      <Card
        isView={TouchableOpacity}
        onPress={() => {
          props.navigation.navigate('Detail', {
            title: itemData.item.title,
            description: itemData.item.description,
            username: itemData.item.username,
            avatar: itemData.item.avatar,
          })
        }}
        style={{ width: '90%', height: 120 }}
      >
        <View
          style={{ flex: 1, justifyContent: 'center', marginHorizontal: 15 }}
        >
          <View style={{ flexDirection: 'row' }}>
            <Image
              source={{ uri: itemData.item.avatar }}
              style={{ width: 55, height: 55, borderRadius: 50 }}
            />
            <View style={{ position: 'absolute', left: '25%', bottom: '45%' }}>
              <Text style={{ fontSize: 18, fontFamily: 'Roboto-Black' }}>
                {itemData.item.username}
              </Text>
              <Text
                style={{
                  fontSize: 18,
                  fontFamily: 'Roboto-Bold',
                  color: 'rgba(150,150,150,150)',
                }}
              >
                {itemData.item.title}
              </Text>
            </View>
          </View>
          <View
            style={{
              position: 'absolute',
              bottom: '15%',
              marginLeft: '25%',
            }}
          >
            <Text numberOfLines={2} style={{ color: 'rgba(150,150,150,150)' }}>
              {itemData.item.description}
            </Text>
          </View>
        </View>
      </Card>
    )
  }
  return (
    <View style={{ flex: 1, backgroundColor: '#FFFFFF' }}>
      <FlatList data={displayedPosts} renderItem={post} />
    </View>
  )
}

export const forumScreenOptions = (navData) => {
  const routeParams = navData.route.params ? navData.route.params : {}

  return {
    headerTitle: routeParams.title,
    headerTitleAlign: 'center',
    headerStyle: {
      backgroundColor: Colors.brandPrimary,
    },
    headerTintColor: 'white',
    headerTitleStyle: {
      fontSize: 25,
    },
    headerRight: () => {
      return (
        <TouchableOpacity
          style={{ marginHorizontal: 15 }}
          onPress={() =>
            navData.navigation.navigate('NewTopic', {
              categoryTitle: routeParams.title,
            })
          }
        >
          <Image
            source={require('../assets/icons/plus.png')}
            style={{ width: 25, height: 25, tintColor: 'white' }}
          />
        </TouchableOpacity>
      )
    },
  }
}

export default ForumScreen
