import React from 'react'
import {
  View,
  Text,
  FlatList,
  Image,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native'
import { CATEGORIES } from '../data/dummy-data'
import Colors from '../constants/Colors'

const ForumCategoriesScreen = (props) => {
  const categoryTile = (itemData) => {
    return (
      <TouchableOpacity
        style={{
          flex: 1,
          width: 150,
          height: 150,
          backgroundColor: 'black',
          marginVertical: 15,
          marginHorizontal: 10,
          borderRadius: 15,
          overflow: 'hidden',
        }}
        onPress={() => {
          props.navigation.navigate('Forum', {
            categoryId: itemData.item.id,
            title: itemData.item.title,
          })
        }}
      >
        <Image
          source={{ uri: itemData.item.image }}
          style={{ width: '100%', height: '100%', opacity: 0.6 }}
        />
        <View style={{ position: 'absolute', bottom: '10%', left: '5%' }}>
          <Text
            style={{ color: 'white', fontSize: 22, fontFamily: 'Roboto-Bold' }}
            numberOfLines={2}
          >
            {itemData.item.title}
          </Text>
        </View>
      </TouchableOpacity>
    )
  }

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: '#FFFFFF',
      }}
    >
      <FlatList data={CATEGORIES} renderItem={categoryTile} numColumns={2} />
    </SafeAreaView>
  )
}

export const categoriesScreenOptions = (navData) => {
  return {
    headerLeft: false,
    title: 'Categories',
    headerTitleAlign: 'center',
    headerStyle: {
      backgroundColor: Colors.brandPrimary,
    },
    headerTintColor: 'white',
    headerTitleStyle: {
      fontSize: 30,
    },
  }
}

export default ForumCategoriesScreen
