import Category from '../models/category'
import Post from '../models/post'

export const CATEGORIES = [
  new Category(
    'c1',
    'Programming',
    'https://images.ctfassets.net/yr4qj72ki4ky/6G2JeQnM8bsnjgoJBjljCh/f30782e127727ee309ebf87fb59cf446/best-programming-languages-2020-Hero.jpg?q=72'
  ),
  new Category(
    'c2',
    'Travels',
    'https://lost-media.com/wp-content/uploads/2019/07/ce-travel.jpg'
  ),
  new Category(
    'c3',
    'Games',
    'https://www.tabletowo.pl/wp-content/uploads/2020/01/Diesel_blog_epic-games-store-update_EGS_Social_Update_News-2560x1440-128a69890d92407b815582c1deba54450e5645f9.jpg'
  ),
  new Category(
    'c4',
    'Food',
    'https://zasoby.ekologia.pl/artykulyNew/26582/xxl/shutterstock-288575585_800x600.jpg'
  ),
  new Category(
    'c5',
    'Ecology',
    'https://facts.net/wp-content/uploads/2020/04/Feature-Image-6.jpg'
  ),
  new Category(
    'c6',
    'TV',
    'https://www.tabletowo.pl/wp-content/uploads/2021/02/Xiaomi-Mi-TV-Q1-75-zrodlo-Xiaomi-4.jpg'
  ),
  new Category(
    'c7',
    'Smartphones',
    'https://fscl01.fonpit.de/userfiles/7695213/image/Smartphones-unter-200-Euro.jpg'
  ),
  new Category(
    'c8',
    'Playstation',
    'https://img.android.com.pl/images/user-images/2020/10/PlayStation-4.jpg'
  ),
  new Category(
    'c9',
    'Apple',
    'https://www.apple.com/ac/structured-data/images/open_graph_logo.png?201810271043'
  ),
  new Category(
    'c10',
    'Headphones',
    'https://www.tabletowo.pl/wp-content/uploads/2021/02/xbox-wireless-headset.jpg'
  ),
]

export const POSTS = [
  new Post(
    '0',
    ['c1'],
    'React-Native',
    'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=400',
    'user1',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis dolorum aliquid maxime tempora ullam repudiandae.'
  ),
  new Post(
    '1',
    ['c1'],
    'JavaScript',
    'https://www.elevatosoftware.com/blog/wp-content/uploads/2019/08/People-Analytics-2.jpg',
    'user23',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis dolorum aliquid maxime tempora ullam repudiandae.'
  ),
  new Post(
    '2',
    ['c1'],
    'C++',
    'https://research.fb.com/wp-content/uploads/2016/11/peopleeric-anderson-7936_finalcrop.jpg?w=300',
    'user1123',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aperiam nisi nobis tempore exercitationem, praesentium laboriosam. Omnis hic temporibus minus quae nesciunt blanditiis, aliquid veniam odio, iure totam assumenda ut adipisci deleniti eius est nemo quisquam.'
  ),
  new Post(
    '3',
    ['c1'],
    'Flutter or react-native',
    'https://media.nature.com/w300/magazine-assets/d41586-021-00808-3/d41586-021-00808-3_18979164.jpg',
    'user112',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis dolorum aliquid maxime tempora ullam repudiandae.'
  ),
  new Post(
    '4',
    ['c3'],
    'Doom',
    'https://i.insider.com/5cb8b133b8342c1b45130629?width=700',
    'user15',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis dolorum aliquid maxime tempora ullam repudiandae.'
  ),
  new Post(
    '5',
    ['c3'],
    'VAC isnt working',
    'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=400',
    'userIme',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis dolorum aliquid maxime tempora ullam repudiandae.'
  ),
  new Post(
    '6',
    ['c10'],
    'Sony xb-900n',
    'https://media.nature.com/w300/magazine-assets/d41586-021-00808-3/d41586-021-00808-3_18979164.jpg',
    'userIme',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis dolorum aliquid maxime tempora ullam repudiandae.'
  ),
  new Post(
    '7',
    ['c9'],
    'M1',
    'https://www.elevatosoftware.com/blog/wp-content/uploads/2019/08/People-Analytics-2.jpg',
    'nazjatar_',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis dolorum aliquid maxime tempora ullam repudiandae.'
  ),
  new Post(
    '8',
    ['c9'],
    'mac mini',
    'https://media.nature.com/w300/magazine-assets/d41586-021-00808-3/d41586-021-00808-3_18979164.jpg',
    'wat',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis dolorum aliquid maxime tempora ullam repudiandae.'
  ),
  new Post(
    '9',
    ['c8'],
    'PS5',
    'https://i.insider.com/5cb8b133b8342c1b45130629?width=700',
    'Farciares',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis dolorum aliquid maxime tempora ullam repudiandae.'
  ),
  new Post(
    '10',
    ['c8'],
    'PS3 Store',
    'https://www.elevatosoftware.com/blog/wp-content/uploads/2019/08/People-Analytics-2.jpg',
    'userIme',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis dolorum aliquid maxime tempora ullam repudiandae.'
  ),
  new Post(
    '11',
    ['c7'],
    'Xiaomi',
    'https://media.nature.com/w300/magazine-assets/d41586-021-00808-3/d41586-021-00808-3_18979164.jpg',
    'xiam_iu',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis dolorum aliquid maxime tempora ullam repudiandae.'
  ),
  new Post(
    '12',
    ['c6'],
    'Sony Tv',
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR34HPVHlAJ85t3Lyy7_9jK48dLrnfqR9ij97pmSr1lyfN_xH9swS14OMeiahE4byecFiA&usqp=CAU',
    'mitrixes',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis dolorum aliquid maxime tempora ullam repudiandae.'
  ),
  new Post(
    '13',
    ['c5'],
    'Wood',
    'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=400',
    'Lovicaw',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis dolorum aliquid maxime tempora ullam repudiandae.'
  ),
  new Post(
    '14',
    ['c4'],
    'MCRoyal vs MCDouble',
    'https://www.elevatosoftware.com/blog/wp-content/uploads/2019/08/People-Analytics-2.jpg',
    'MCIDOL',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis dolorum aliquid maxime tempora ullam repudiandae.'
  ),
  new Post(
    '15',
    ['c1'],
    'C#',
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR34HPVHlAJ85t3Lyy7_9jK48dLrnfqR9ij97pmSr1lyfN_xH9swS14OMeiahE4byecFiA&usqp=CAU',
    'urPython',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis dolorum aliquid maxime tempora ullam repudiandae.'
  ),
  new Post(
    '16',
    ['c1'],
    'Python',
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR34HPVHlAJ85t3Lyy7_9jK48dLrnfqR9ij97pmSr1lyfN_xH9swS14OMeiahE4byecFiA&usqp=CAU',
    'uasseras',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis dolorum aliquid maxime tempora ullam repudiandae.'
  ),
  new Post(
    '17',
    ['c1'],
    'React-Native',
    'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=400',
    'VCTmaster',
    'TypeError: undefined is not an object (evaluating initialState())'
  ),
  new Post(
    '18',
    ['c1'],
    'Machine Learning',
    'https://i.insider.com/5cb8b133b8342c1b45130629?width=700',
    'python Master',
    'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis dolorum aliquid maxime tempora ullam repudiandae.'
  ),
]
